date
echo 'pqt_1';sudo ./rvs -c conf/pqt_1.conf -d 3; date
echo 'pqt_12';sudo ./rvs -c conf/pqt_12.conf -d 3; date
echo 'pqt_13';sudo ./rvs -c conf/pqt_13.conf -d 3; date
echo 'pqt_14';sudo ./rvs -c conf/pqt_14.conf -d 3; date
echo 'pqt_15';sudo ./rvs -c conf/pqt_15.conf -d 3; date
echo 'pqt_16';sudo ./rvs -c conf/pqt_16.conf -d 3; date
echo 'pqt_example1';sudo ./rvs -c conf/pqt_example1.conf -d 3; date
echo 'pqt_example2';sudo ./rvs -c conf/pqt_example2.conf -d 3; date
echo 'pqt_example3';sudo ./rvs -c conf/pqt_example3.conf -d 3; date
echo 'pqt_example4';sudo ./rvs -c conf/pqt_example4.conf -d 3; date
echo 'pqt_example5';sudo ./rvs -c conf/pqt_example5.conf -d 3; date
echo 'pqt_example6';sudo ./rvs -c conf/pqt_example6.conf -d 3; date
echo 'pqt_example7';sudo ./rvs -c conf/pqt_example7.conf -d 3; date
echo 'pqt_sanity';sudo ./rvs -c conf/pqt_sanity.conf -d 3; date
