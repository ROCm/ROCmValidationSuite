date
echo 'gst';sudo ./rvs -c conf/gst.conf -d 3; date 
echo 'gst_1';sudo ./rvs -c conf/gst_1.conf -d 3; date
echo 'gst_2';sudo ./rvs -c conf/gst_2.conf -d 3; date
echo 'gst_3';sudo ./rvs -c conf/gst_3.conf -d 3; date
echo 'gst_4';sudo ./rvs -c conf/gst_4.conf -d 3; date
echo 'gst_5';sudo ./rvs -c conf/gst_5.conf -d 3; date
echo 'gst_6';sudo ./rvs -c conf/gst_6.conf -d 3; date
echo 'gst_7';sudo ./rvs -c conf/gst_7.conf -d 3; date
