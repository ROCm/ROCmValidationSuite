echo 'peqt_1';sudo ./rvs -c conf/peqt_1.conf -d 3;date 
echo 'peqt_2';sudo ./rvs -c conf/peqt_2.conf -d 3;date 
echo 'peqt_3';sudo ./rvs -c conf/peqt_3.conf -d 3;date 
echo 'peqt_4';sudo ./rvs -c conf/peqt_4.conf -d 3;date 
echo 'peqt_5';sudo ./rvs -c conf/peqt_5.conf -d 3;date 
echo 'peqt_6';sudo ./rvs -c conf/peqt_6.conf -d 3;date 
echo 'peqt_7';sudo ./rvs -c conf/peqt_7.conf -d 3;date 
echo 'peqt_8';sudo ./rvs -c conf/peqt_8.new.conf -d 3;date 
echo 'peqt_9';sudo ./rvs -c conf/peqt_9.conf -d 3;date 
echo 'peqt_10';sudo ./rvs -c conf/peqt_10.conf -d 3;date
echo 'peqt_11';sudo ./rvs -c conf/peqt_11.conf -d 3;date
echo 'peqt_12';sudo ./rvs -c conf/peqt_12.conf -d 3;date
echo 'peqt_13';sudo ./rvs -c conf/peqt_13.conf -d 3;date
echo 'peqt_14';sudo ./rvs -c conf/peqt_14.conf -d 3;date
echo 'peqt_15';sudo ./rvs -c conf/peqt_15.conf -d 3;date
echo 'peqt_16';sudo ./rvs -c conf/peqt_16.conf -d 3;date
echo 'peqt_17';sudo ./rvs -c conf/peqt_17.conf -d 3;date
echo 'peqt_18';sudo ./rvs -c conf/peqt_18.conf -d 3;date
echo 'peqt_regex_no_match';sudo ./rvs -c conf/peqt_regex_no_match.conf -d 3;date
echo 'peqt_wrong_regex';sudo ./rvs -c conf/peqt_wrong_regex.conf -d 3;date 


