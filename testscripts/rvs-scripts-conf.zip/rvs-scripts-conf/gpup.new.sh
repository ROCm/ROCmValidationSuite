date
echo 'gpup_1';sudo ./rvs -c conf/gpup_1.conf -d 3; date
echo 'gpup_2';sudo ./rvs -c conf/gpup_2.conf -d 3; date
echo 'gpup_3';sudo ./rvs -c conf/gpup_3.conf -d 3; date
echo 'gpup_4';sudo ./rvs -c conf/gpup_4.conf -d 3; date
echo 'gpup_5';sudo ./rvs -c conf/gpup_5.conf -d 3; date
echo 'gpup_6';sudo ./rvs -c conf/gpup_6.conf -d 3; date
echo 'gpup_7';sudo ./rvs -c conf/gpup_7.conf -d 3; date
