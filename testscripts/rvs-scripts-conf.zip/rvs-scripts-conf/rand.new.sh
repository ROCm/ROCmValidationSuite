date
echo 'rand_pqt1';sudo ./rvs -c conf/rand_pqt1.conf -d 3; date
echo 'rand_pqt3';sudo ./rvs -c conf/rand_pqt3.conf -d 3; date
echo 'rand_pqt4';sudo ./rvs -c conf/rand_pqt4.conf -d 3; date
echo 'rand_pqt5';sudo ./rvs -c conf/rand_pqt5.conf -d 3; date
echo 'rand_pqt6';sudo ./rvs -c conf/rand_pqt6.conf -d 3; date
echo 'rand_pqt7';sudo ./rvs -c conf/rand_pqt7.conf -d 3; date
echo 'rand_pqt8';sudo ./rvs -c conf/rand_pqt8.conf -d 3; date
echo 'rand_pqt9';sudo ./rvs -c conf/rand_pqt9.conf -d 3; date
echo 'rand_pqt10';sudo ./rvs -c conf/rand_pqt10.conf -d 3; date
echo 'rand_pqt11';sudo ./rvs -c conf/rand_pqt11.conf -d 3; date
echo 'rand_pqt12';sudo ./rvs -c conf/rand_pqt12.conf -d 3; date
echo 'rand_pqt13';sudo ./rvs -c conf/rand_pqt13.conf -d 3; date
echo 'rand_pqt14';sudo ./rvs -c conf/rand_pqt14.conf -d 3; date
echo 'rand_pqt15';sudo ./rvs -c conf/rand_pqt15.conf -d 3; date
echo 'rand_pqt16';sudo ./rvs -c conf/rand_pqt16.conf -d 3; date
echo 'rand_pqt17';sudo ./rvs -c conf/rand_pqt17.conf -d 3; date
echo 'rand_pqt18';sudo ./rvs -c conf/rand_pqt18.conf -d 3; date
echo 'rand_pqt19';sudo ./rvs -c conf/rand_pqt19.conf -d 3; date
echo 'rand_pqt20';sudo ./rvs -c conf/rand_pqt20.conf -d 3; date
echo 'rand_pqt21';sudo ./rvs -c conf/rand_pqt21.conf -d 3; date
echo 'rand_pqt22';sudo ./rvs -c conf/rand_pqt22.conf -d 3; date
echo 'rand_pqt23';sudo ./rvs -c conf/rand_pqt23.conf -d 3; date
echo 'rand_pqt24';sudo ./rvs -c conf/rand_pqt24.conf -d 3; date
echo 'rand_pqt25';sudo ./rvs -c conf/rand_pqt25.conf -d 3; date

