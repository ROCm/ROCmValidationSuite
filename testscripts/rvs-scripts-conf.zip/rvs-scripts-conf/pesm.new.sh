date
echo 'pesm_1';sudo ./rvs -c conf/pesm_1.conf -d 3; date
echo 'pesm_2';sudo ./rvs -c conf/pesm_2.conf -d 3; date
echo 'pesm_3';sudo ./rvs -c conf/pesm_3.conf -d 3; date
echo 'pesm_4';sudo ./rvs -c conf/pesm_4.conf -d 3; date
echo 'pesm_5';sudo ./rvs -c conf/pesm_5.conf -d 3; date
echo 'pesm_6';sudo ./rvs -c conf/pesm_5.conf -d 3; date
echo 'pesm_7';sudo ./rvs -c conf/pesm_7.conf -d 3; date
echo 'pesm_8';sudo ./rvs -c conf/pesm_8.conf -d 3; date
echo 'pesm_9';sudo ./rvs -c conf/pesm_9.conf -d 3; date

